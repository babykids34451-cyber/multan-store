# Shaan Online Store - Website (Customer Storefront)

This package contains the complete customer-facing eCommerce web application for Shaan Online Store.

## Features Included:
- Premium Pakistani Fashion & Lifestyle Storefront
- Product catalog, category filters, and quick view
- Shopping Cart & Slide-Over Drawer
- Cash on Delivery (COD) Checkout & SBP Raast Bank QR verification
- WhatsApp 1-Click Order Buttons
- Live Order Tracking by Phone / Order ID
- Customer Account & Wishlist
- Responsive Mobile-First App Navigation

## How to Run:
1. Extract this zip file.
2. Run:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Build for production deployment:
   ```bash
   npm run build
   ```
