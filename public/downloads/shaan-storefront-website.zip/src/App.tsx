import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { QuickViewModal } from './components/QuickViewModal';
import { ToastContainer } from './components/ToastContainer';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton';
import { MobileBottomNav } from './components/MobileBottomNav';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { TrackOrderPage } from './pages/TrackOrderPage';
import { WishlistPage } from './pages/WishlistPage';
import { AccountPage } from './pages/AccountPage';
import { InformationPages } from './pages/InformationPages';
import { Product, Order } from './types';

const MainLayout: React.FC = () => {
  const { products, getProductById, getProductBySlug } = useStore();

  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParam, setViewParam] = useState<string | undefined>(undefined);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  const handleNavigate = (view: string, param?: string) => {
    setViewParam(param);

    if (view === 'product-details' && param) {
      const found = getProductBySlug(param) || getProductById(param);
      if (found) {
        setSelectedProduct(found);
        setCurrentView('product-details');
      } else {
        setCurrentView('shop');
      }
    } else {
      setCurrentView(view);
    }
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setCurrentView('product-details');
  };

  const handleOrderSuccess = (order: Order) => {
    setConfirmedOrder(order);
    setCurrentView('order-confirmation');
  };

  return (
    <div className="w-full max-w-full min-h-screen min-h-[100dvh] overflow-x-hidden flex flex-col bg-slate-50 text-slate-900 selection:bg-rose-600 selection:text-white font-sans antialiased">
      <Header currentView={currentView} onNavigate={handleNavigate} />

      <main className="flex-1 w-full max-w-full overflow-x-hidden pb-20 lg:pb-0">
        {currentView === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'shop' && (
          <ShopPage
            initialFilterParam={viewParam}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'product-details' && selectedProduct && (
          <ProductDetailsPage
            product={selectedProduct}
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {currentView === 'checkout' && (
          <CheckoutPage
            onNavigate={handleNavigate}
            onOrderSuccess={handleOrderSuccess}
          />
        )}

        {currentView === 'order-confirmation' && (
          <OrderConfirmationPage
            order={confirmedOrder}
            onNavigate={handleNavigate}
          />
        )}

        {currentView === 'track' && (
          <TrackOrderPage onNavigate={handleNavigate} />
        )}

        {currentView === 'wishlist' && (
          <WishlistPage
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {(currentView === 'account' || currentView === 'orders') && (
          <AccountPage onNavigate={handleNavigate} />
        )}

        {currentView === 'about' && (
          <InformationPages type="about" onNavigate={handleNavigate} />
        )}

        {currentView === 'contact' && (
          <InformationPages type="contact" onNavigate={handleNavigate} />
        )}

        {currentView === 'faq' && (
          <InformationPages type="faq" onNavigate={handleNavigate} />
        )}

        {currentView === 'shipping-policy' && (
          <InformationPages type="shipping" onNavigate={handleNavigate} />
        )}

        {currentView === 'return-policy' && (
          <InformationPages type="returns" onNavigate={handleNavigate} />
        )}

        {currentView === 'privacy-policy' && (
          <InformationPages type="privacy" onNavigate={handleNavigate} />
        )}

        {currentView === 'terms' && (
          <InformationPages type="terms" onNavigate={handleNavigate} />
        )}
      </main>

      <Footer onNavigate={handleNavigate} />
      <MobileBottomNav currentView={currentView} onNavigate={handleNavigate} />
      <CartDrawer
        onNavigateToCheckout={() => setCurrentView('checkout')}
        onNavigateToShop={() => setCurrentView('shop')}
      />
      <QuickViewModal />
      <ToastContainer />
      <WhatsAppFloatingButton />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainLayout />
    </StoreProvider>
  );
}
