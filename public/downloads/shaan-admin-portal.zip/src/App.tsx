import React from 'react';
import { StoreProvider } from './context/StoreContext';
import { AdminPanelPage } from './pages/AdminPanelPage';
import { ToastContainer } from './components/ToastContainer';

const AdminApp: React.FC = () => {
  return (
    <div className="w-full min-h-screen bg-slate-950 text-slate-100 font-sans antialiased">
      <AdminPanelPage
        onNavigateToStore={() => {
          alert('This is the standalone Admin Portal. Open the Website package to view the public storefront.');
        }}
      />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AdminApp />
    </StoreProvider>
  );
}
