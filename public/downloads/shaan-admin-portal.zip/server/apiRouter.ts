import express, { Request, Response } from 'express';

export const apiRouter = express.Router();

// Ensure res.status, res.json, and res.send are available when used as Connect middleware in Vite
apiRouter.use((_req: Request, res: Response, next) => {
  const resAny = res as any;
  if (typeof resAny.status !== 'function') {
    resAny.status = function (statusCode: number) {
      this.statusCode = statusCode;
      return this;
    };
  }
  if (typeof resAny.json !== 'function') {
    resAny.json = function (data: unknown) {
      this.setHeader('Content-Type', 'application/json');
      this.end(JSON.stringify(data));
      return this;
    };
  }
  if (typeof resAny.send !== 'function') {
    resAny.send = function (data: unknown) {
      if (typeof data === 'object' && data !== null) {
        return this.json(data);
      }
      this.end(data);
      return this;
    };
  }
  next();
});

apiRouter.use(express.json());
apiRouter.use(express.urlencoded({ extended: true }));

// SBP Raast & QR Code payment configuration endpoint
apiRouter.get('/raast/config', (_req: Request, res: Response) => {
  const raastId = process.env.RAAST_ID || '03124352369';
  const accountTitle = process.env.RAAST_ACCOUNT_TITLE || 'Muhammad Muzamil';
  const rawBankName = process.env.RAAST_BANK_NAME;
  let bankName = 'JS Bank / ZINDIGI';
  if (rawBankName) {
    if (rawBankName.toUpperCase() === 'ZINDIGI' || rawBankName.toUpperCase() === 'JS BANK / ZINDIGI') {
      bankName = 'JS Bank / ZINDIGI';
    } else if (rawBankName.toLowerCase().includes('js bank')) {
      bankName = rawBankName;
    } else {
      bankName = `JS Bank / ${rawBankName}`;
    }
  }
  const iban = process.env.RAAST_IBAN || 'PK70JSBL9999903124352369';

  res.json({
    enabled: true,
    raastId,
    accountTitle,
    bankName,
    iban,
    currency: 'PKR',
    instructions:
      'Transfer exact order amount using any Pakistani banking app (EasyPaisa, JazzCash, Nayapay, Sadapay, Meezan, HBL, UBL, etc.) via Raast ID or Bank QR, then submit your Transaction ID (TRX ID).',
  });
});

// Verify & record customer transaction ID / proof reference
apiRouter.post('/raast/verify-trx', (req: Request, res: Response) => {
  const { orderId, transactionId, customerPhone, amount } = req.body;

  if (!transactionId || typeof transactionId !== 'string' || transactionId.trim().length < 4) {
    return res.status(400).json({
      valid: false,
      message: 'Please provide a valid 6 to 12 digit Transaction ID (TRX ID) from your banking receipt.',
    });
  }

  // Clean and sanitize TRX ID
  const cleanTrx = transactionId.trim().toUpperCase();

  return res.json({
    valid: true,
    transactionId: cleanTrx,
    orderId,
    amount,
    customerPhone,
    status: 'received',
    message: 'Transaction reference recorded. Our billing team will verify it with your bank statement.',
  });
});

// Legacy backward-compatibility endpoint (in case of cached client requests)
apiRouter.get('/jazzcash/status', (_req: Request, res: Response) => {
  res.json({
    configured: false,
    mode: 'deprecated',
    message: 'Standard SBP Raast ID and QR Code payment is now active on Shaan Online Store.',
  });
});
