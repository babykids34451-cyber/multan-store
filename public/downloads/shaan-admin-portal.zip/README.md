# Shaan Online Store - Admin & Store Management Portal

This package contains the standalone Admin Management Portal for Shaan Online Store.

## Features Included:
- Master Store Settings (Logo, Brand Name, Short Name, Tagline)
- Product & Inventory Management (Add, Edit, Delete, Stock Levels, Variations)
- Categories & Home Slider Banner Controls
- Order Dispatch & Real-time Order Tracking Status Updates (Pending, Processing, Shipped, Delivered)
- SBP Raast Bank Settings (Raast ID, Account Title, Bank Name, IBAN)
- WhatsApp Order Dispatch and Customer Helpline Numbers
- Discount Coupons Engine & Analytics Overview
- Direct PDF / Thermal Print Invoices for Courier Dispatch

## Default Credentials:
- **Admin Password:** `admin123`

## How to Run:
1. Extract this zip file.
2. Run:
   ```bash
   npm install
   ```
3. Start development server:
   ```bash
   npm run dev
   ```
4. Build for production deployment:
   ```bash
   npm run build
   ```
